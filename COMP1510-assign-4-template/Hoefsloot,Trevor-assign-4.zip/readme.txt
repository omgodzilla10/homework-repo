Trevor Hoefsloot, A00957323, 1E, Dec 2nd 2015

This assignment is 100% complete.


------------------------
Question one (Statistics) status:

Complete

------------------------
Question two (DrawTriangle) status:

Complete

------------------------
Question three (StopWatch) status:

Complete
