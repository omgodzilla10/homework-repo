package ca.bcit.comp2526.a1b;

import java.util.Scanner;

/**
 * ConsoleUserInterface.
 * @author your name here
 * @version
 */
public class ConsoleUserInterface {
    private final Scanner input;
    private AddressBook addressBook;

    /**
     * Constructor for objects of type ConsoleUserInterface.
     */
    public ConsoleUserInterface() {
        input = new Scanner(System.in);
    }

}
